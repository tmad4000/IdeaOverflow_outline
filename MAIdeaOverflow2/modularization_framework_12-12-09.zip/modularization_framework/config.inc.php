<?php
 # config.inc.php

/* 
 *	File name: config.inc.php
 *	Created by: Jacob Cole, built off of framework by Larry Ullman of DMC Insights, Inc. 
 *	Contact: tmad4000@gmail.com
 *	Last modified: 
 *	
 *	Configuration file does the following things:
 *	- Has site settings in one location.
 *	- Stores URLs and URIs as constants.
 *	- Sets how errors will be handled.
 *
 * Note: This file should be stored one level above the directory of index.php
 */

# ******************** #
# ***** SETTINGS ***** #


/*
 *	The $debug variable is used to set error management.
 *	To debug a specific page, add this to the index.php page:
if ($p == 'thismodule') $debug = TRUE;
require_once('./includes/config.inc.php');
 *  NOTE: Debug is automatically set to TRUE when script is run locally
 */
 
$debug = FALSE; //if true, all pages are debugged, if false, pages where debug mode is locally enabled are debugged. Errors are not emailed when $debug is true


define('EMAIL_ERRORS',FALSE); //determines if erros are emailed
define('ERROR_EMAIL','address@example.com'); //address to which errors are emailed if EMAIL_ERRORS is true and $debug is false

//remote path constants
define ('BASE_URI_REMOTE', '');
define ('BASE_URL_REMOTE',	'http://jacobsstuff.tpclubs.com/files/modularization_framework/');
define ('DB_REMOTE', 'includes/db/mysql.inc.php'); //unused in this demo

//local path constants for testing
define ('BASE_URI_LOCAL', '/path/to/local/html/folder/');
define ('BASE_URL_LOCAL',	'http://localhost/directory/');
define ('DB_LOCAL', '/path/to/local/mysql.inc.php');


# ***** END SETTINGS ***** #
# ******************** #



// Determine whether we're working on a local server
// or on the real server:
if (stristr($_SERVER['HTTP_HOST'], 'local') || (substr($_SERVER['HTTP_HOST'], 0, 7) == '192.168')) {
	$local = TRUE;
} else {
	$local = FALSE;
}

// Determine location of files and the URL of the site:
// Allow for development on different servers.
if ($local) {
	// Always debug when running locally:
	$debug = TRUE;	
	
	// Define local path constants:
	define ('BASE_URI', BASE_URI_LOCAL);
	define ('BASE_URL',	BASE_URL_LOCAL);
	define ('DB', DB_LOCAL);
	
} else {

	define ('BASE_URI', BASE_URI_REMOTE);
	define ('BASE_URL',	BASE_URL_REMOTE);
	define ('DB', DB_REMOTE);
}
	


// Assume debugging is off if unset. 
if (!isset($debug)) {
	$debug = FALSE;
}


# **************************** #
# ***** ERROR MANAGEMENT ***** #

// Create the error handler.
function my_error_handler ($e_number, $e_message, $e_file, $e_line, $e_vars) {

	global $debug;
	
	// Build the error message.
	$message = "An error occurred in script '$e_file' on line $e_line: \n<br />$e_message\n<br />";
	
	// Add the date and time.
	$message .= "Date/Time: " . date('n-j-Y H:i:s') . "\n<br />";
	
	// Append $e_vars to the $message.
	$message .= "<pre>" . print_r ($e_vars, 1) . "</pre>\n<br />";
	
	if ($debug) { // Show the error.
	
		echo '<p class="error">' . $message . '</p>';
		
	} elseif(EMAIL_ERRORS) { 
	
		// Log the error:
		error_log ($message, 1, ERROR_EMAIL); // Send email.
		
		// Only print an error message if the error isn't a notice or strict.
		if ( ($e_number != E_NOTICE) && ($e_number < 2048)) {
			echo '<p class="error">A system error occurred. We apologize for the inconvenience.</p>';
		}
		
	} // End of $debug IF.

} // End of my_error_handler() definition.

// Use my error handler:
set_error_handler ('my_error_handler');

# ***** ERROR MANAGEMENT ***** #
# **************************** #
?>