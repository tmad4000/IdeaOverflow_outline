<?php		
		# .inc.php
		
		/* 	
		 *	This page is included by index.php.
		 */
		
		// Redirect if this page was accessed directly:
		if (!defined('BASE_URL')) {
		
			// Need the BASE_URL, defined in the config file:
			require_once ('../../config.inc.php');
			
			// Redirect to the index page:
			$url = BASE_URL . 'index.php';
			header ("Location: $url");
			exit;
			
		} // End of defined() IF.
			?><!-- %BEGIN CONTENT% -->

  <div class="date_box">
<div class="date_box_month">Jan</div>
<div class="date_box_day">18</div>
</div>
<h3>Lorem Ipsum sample text  </h3>


  <p><img src="images/demo_img.jpg" height="140" class="float_right" style="position:relative;right:13px" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. <a href="http://www.csstemplateheaven.com">Curabitur nibh</a>. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
  
  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum sapien enim, cursus in, aliquam sit amet, convallis eget, metus. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean orci mi, varius eget, mollis vel, rhoncus a, leo. Ut eros enim, vehicula quis, gravida ac, sodales sit amet, orci. Nulla eleifend tristique erat.&nbsp;</p>
  
  <p class="read_more"><a href="#"><img src="images/arrow.png" alt="read more" width="16" height="12" />Further reading</a> </p>
  
  
  <div class="date_box">
<div class="date_box_month">Jan</div>
<div class="date_box_day">12</div>
</div>


<h3>A blockquote</h3>
  
  <blockquote><p class="quote">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum sapien enim, cursus in, aliquam sit amet, convallis eget, metus. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean orci mi, varius eget, mollis vel, rhoncus a, leo. Ut eros enim, vehicula quis, gravida ac, sodales sit amet, orci. Nulla eleifend tristique erat. Sed ac est. Fusce tincidunt luctus tortor. Quisque sed neque vitae elit cursus faucibus.</p></blockquote>
  
  <p>Duis mauris justo, tincidunt in, molestie sed, lacinia vel, dolor. Aenean ac tellus porttitor ligula hendrerit ornare. Vivamus gravida ornare augue. Proin porta, quam a vulputate blandit, massa lorem euismod eros, vel nonummy enim sapien eget nisi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In dapibus commodo dolor. Aliquam facilisis turpis ac tortor. Quisque quis velit eget lacus consectetuer volutpat. Cras nibh. Sed quis justo. In neque lacus, sagittis id, lobortis nec, congue id, diam. Phasellus ut pede. Praesent porta consectetuer dui. Praesent mattis neque. Nunc commodo facilisis ipsum. Etiam scelerisque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec ut quam. Nullam mauris nulla, dictum vulputate, pharetra vel, tempor nec, sem. Pellentesque scelerisque. </p>
  
    <p class="read_more"><a href="#"><img src="images/arrow.png" alt="read more" width="16" height="12" />Further reading</a> </p>

<!-- %END CONTENT% -->