<?php		
		# .inc.php
		
		/* 	
		 *	This page is included by index.php.
		 */
		
		// Redirect if this page was accessed directly:
		if (!defined('BASE_URL')) {
		
			// Need the BASE_URL, defined in the config file:
			require_once ('../../config.inc.php');
			
			// Redirect to the index page:
			$url = BASE_URL . 'index.php';
			header ("Location: $url");
			exit;
			
		} // End of defined() IF.
			?><!-- %BEGIN CONTENT% -->
			<div align="center"><img src="images/demo_img.jpg" alt="Alt" height="200" /></div>
			<p>
			Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum sapien enim, cursus in, aliquam sit amet, convallis eget, metus. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean orci mi, varius eget, mollis vel, rhoncus a, leo. Ut eros enim, vehicula quis, gravida ac, sodales sit amet, orci. Nulla eleifend tristique erat. 
			</p>
			<div align="center">Ipsum Lorem Dolor</div><br />
              <br />

		      <!-- %END CONTENT% -->