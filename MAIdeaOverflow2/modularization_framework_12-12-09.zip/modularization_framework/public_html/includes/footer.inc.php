<!-- %BEGIN FOOTER% -->  
</div>
<div id="footer" style="color:#999999">&copy; 2008 Ipsum Lorem | Sit Amet | <a href="http://www.csstemplateheaven.com">Related Websites </a> </div>
<!-- Based on a template from http://www.csstemplateheaven.com -->
</div>

<script type="text/javascript">
//<!--
	var theBrowser=navigator;
	if(theBrowser.appName=="Microsoft Internet Explorer" && (theBrowser.appVersion.substr(0,1)-0)<=4)
	{
		document.getElementById('left').style.marginLeft="22px";		
	}
//-->
</script>
</body>
</html>