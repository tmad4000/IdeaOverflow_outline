<?php
 # config_modulebuilder.inc.php
/** 
 * contains configuration information and constants for modulebuilder 
 * should be required at top of every page
 */

# ******************** #
# ***** SETTINGS ***** #

define('ADMIN_PASS','asdf');

//globally necessary vars
$indexDir="../";
$modulesPath="modules/";
$includesPath="includes/";
$inFilePathRegex='/index_([a-zA-Z_\/]+)\.php/';

//delimeters - MUST ONLY OCCUR ONCE
$indexDelims=array('begin'=>'/*%BEGIN CASELIST%*/','end'=>'/*%END CASELIST%*/');
$contentDelims=array('begin'=>'<!-- %BEGIN CONTENT% -->','end'=>'<!-- %END CONTENT% -->');
define('HEADER_END_DELIM','<!-- %END HEADER% -->');
define('FOOTER_BEGIN_DELIM','<!-- %BEGIN FOOTER% -->');


# ******************** #
# ***** DEFAULT INITIAL DATA ***** #
	
	
//information that goes at top of every module the necessary information
$modulePrependInfo=<<<EOD
		
		# $moduleName.inc.php
		
		/* 	
		 *	This page is included by index.php.
		 */
		
		// Redirect if this page was accessed directly:
		if (!defined('BASE_URL')) {
		
			// Need the BASE_URL, defined in the config file:
			require_once ('../../config.inc.php');
			
			// Redirect to the index page:
			\$url = BASE_URL . 'index.php';
			header ("Location: \$url");
			exit;
			
		} // End of defined() IF.
			
EOD;

//add the PHP tags
$modulePrependInfo='<?php'.$modulePrependInfo.'?>';

$newModuleContent=<<<EOD

		<!-- %BEGIN CONTENT% -->
		
		<!-- %END CONTENT% -->	
		
EOD;

?>