<?php #header.inc.php

// This page begins the HTML header for the site.

// Check for a $page_title value:
if (!isset($page_title)) $page_title = 'Demo Site';
//else $page_title=' - '.$page_title;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $page_title ?></title>

<link rel="stylesheet" type="text/css" href="styles/style.css" />
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:286px;
	height:49px;
	z-index:1;
}
.style1 {font-size: 1em}
.style2 {color: #000000}
-->
</style>
<script src="Scripts/AC_ActiveX.js" type="text/javascript"></script>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>

<body>

<div id="container">

<div id="header">

<div id="header_left">
<h1><span class="red">Demo Site </span></h1>
<h2>Demo Subtitle </h2>
</div>

<div id="header_right">

<p class="welcome style1" style="font-size:12px">Proudly sponsored by<br />
  <br />
  <br />
      <span class="style2"><strong>[Sponsor Logo Here] </strong></span></p>

  <span class="style2"><strong>
  <!--
<p class="welcome">Welcome, Guest. Please login or <a href="#">register</a>.</p>

  <form id="form1" method="post" action="">
    <p><label>Username
    <input type="text" class="fields" name="textfield" />
    </label>
    <label>Password
    <input type="text" class="fields" name="textfield2" />
    <input type="submit" class="submit_button" name="Submit" value="login" />
    </label></p>
  </form>

-->
  </strong></span></div>
</div>
<div id="page_name"><?php echo $page_name; ?></div>

<div id="left">
<div id="flash"> <script type="text/javascript">
AC_AX_RunContent( 'height','90','width','225','src','flash/vines.swf','wmode','transparent','movie','flash/vines.swf' ); //end AC code
</script><noscript><object height="90" width="225"><param value="flash/vines.swf" name="movie" /> <embed src="flash/vines.swf" wmode="transparent" height="90" width="225"></object></noscript></div>
<h4 style="margin-top:40px"><span class="menu_first_letter">Navigation</span></h4>

<div id="navcontainer">
<ul id="navlist">
<li <?php $currPg='home'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Home</a></li>
<li <?php $currPg='aboutme'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">About Me</a></li>
<li <?php $currPg='blog'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Blog</a></li>
<li <?php $currPg='artsandmusic'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Arts & Music</a></li></ul>
</div>

<h4>Contact</h4>


  <form id="form2" method="post" class="contact_us" action="">
    <p><label>Name
    <input type="text" class="fields_contact_us" name="textfield" />
    </label>
    <label>E-mail
    <input type="text" class="fields_contact_us" name="textfield2" />
	</label>
	<label>
    Your message:
    <textarea name="textarea" cols="" rows=""></textarea>
	</label>
    <label>
    <input type="submit" class="submit_button_contact" name="Submit3" value="Submit" />
    </label></p>
  </form>

<h4>Suggested links </h4>



<a href="#">Lorem</a></div>
<div id="right">
<!-- %END HEADER% --><!-- %BEGIN CONTENT% -->

  <div class="date_box">
<div class="date_box_month">Jan</div>
<div class="date_box_day">18</div>
</div>
<h3>Lorem Ipsum sample text  </h3>


  <p><img src="images/demo_img.jpg" height="140" class="float_right" style="position:relative;right:13px" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. <a href="http://www.csstemplateheaven.com">Curabitur nibh</a>. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
  
  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum sapien enim, cursus in, aliquam sit amet, convallis eget, metus. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean orci mi, varius eget, mollis vel, rhoncus a, leo. Ut eros enim, vehicula quis, gravida ac, sodales sit amet, orci. Nulla eleifend tristique erat.&nbsp;</p>
  
  <p class="read_more"><a href="#"><img src="images/arrow.png" alt="read more" width="16" height="12" />Further reading</a> </p>
  
  
  <div class="date_box">
<div class="date_box_month">Jan</div>
<div class="date_box_day">12</div>
</div>


<h3>A blockquote</h3>
  
  <blockquote><p class="quote">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum sapien enim, cursus in, aliquam sit amet, convallis eget, metus. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean orci mi, varius eget, mollis vel, rhoncus a, leo. Ut eros enim, vehicula quis, gravida ac, sodales sit amet, orci. Nulla eleifend tristique erat. Sed ac est. Fusce tincidunt luctus tortor. Quisque sed neque vitae elit cursus faucibus.</p></blockquote>
  
  <p>Duis mauris justo, tincidunt in, molestie sed, lacinia vel, dolor. Aenean ac tellus porttitor ligula hendrerit ornare. Vivamus gravida ornare augue. Proin porta, quam a vulputate blandit, massa lorem euismod eros, vel nonummy enim sapien eget nisi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In dapibus commodo dolor. Aliquam facilisis turpis ac tortor. Quisque quis velit eget lacus consectetuer volutpat. Cras nibh. Sed quis justo. In neque lacus, sagittis id, lobortis nec, congue id, diam. Phasellus ut pede. Praesent porta consectetuer dui. Praesent mattis neque. Nunc commodo facilisis ipsum. Etiam scelerisque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec ut quam. Nullam mauris nulla, dictum vulputate, pharetra vel, tempor nec, sem. Pellentesque scelerisque. </p>
  
    <p class="read_more"><a href="#"><img src="images/arrow.png" alt="read more" width="16" height="12" />Further reading</a> </p>

<!-- %END CONTENT% --><!-- %BEGIN FOOTER% -->  
</div>
<div id="footer" style="color:#999999">&copy; 2008 Ipsum Lorem | Sample design: OSWD <a href="http://www.oswd.org/design/preview/id/3691" target="_blank">Delicious Fruit</a> | <a href="http://www.csstemplateheaven.com">Related Websites </a> </div>
<!-- Based on a template from http://www.csstemplateheaven.com -->
</div>

<script type="text/javascript">
//<!--
	var theBrowser=navigator;
	if(theBrowser.appName=="Microsoft Internet Explorer" && (theBrowser.appVersion.substr(0,1)-0)<=4)
	{
		document.getElementById('left').style.marginLeft="22px";		
	}
//-->
</script>
</body>
</html>