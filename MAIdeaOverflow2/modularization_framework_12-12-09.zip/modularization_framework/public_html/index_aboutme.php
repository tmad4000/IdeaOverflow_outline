<?php #header.inc.php

// This page begins the HTML header for the site.

// Check for a $page_title value:
if (!isset($page_title)) $page_title = 'Belly Bountiful';
//else $page_title=' - '.$page_title;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $page_title ?></title>

<link rel="stylesheet" type="text/css" href="styles/style.css" />
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:286px;
	height:49px;
	z-index:1;
}
.style1 {font-size: 1em}
-->
</style>
</head>

<body>

<div id="container">

<div id="header">

<div id="header_left">
<h1><span class="red">Belly Bountiful </span></h1>
<h2>Birth Experience </h2>
</div>

<div id="header_right">

<p class="welcome style1" style="font-size:12px">Proudly sponsored by</p>

  <!--
<p class="welcome">Welcome, Guest. Please login or <a href="#">register</a>.</p>

  <form id="form1" method="post" action="">
    <p><label>Username
    <input type="text" class="fields" name="textfield" />
    </label>
    <label>Password
    <input type="text" class="fields" name="textfield2" />
    <input type="submit" class="submit_button" name="Submit" value="login" />
    </label></p>
  </form>

-->
</div>
</div>
<div id="page_name"><?php echo $page_name; ?></div>

<div id="left">
<div id="flash"> <object height="90" width="225"><param value="flash/vines.swf" name="movie" /> <embed src="flash/vines.swf" wmode="transparent" height="90" width="225"></object></div>
<h4><span class="menu_first_letter">Navigation</span></h4>

<div id="navcontainer">
<ul id="navlist">
<li <?php $currPg='home'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Home</a></li>
<li <?php $currPg='aboutme'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">About Me</a></li>
<li <?php $currPg='childbirtheducation'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Childbirth Education</a></li>
<li <?php $currPg='birtharoundtheworld'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Birth  Around the World</a></li>
<li <?php $currPg='wisdomcorner'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Wisdom Corner</a></li>
<li <?php $currPg='artsandmusic'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Arts and Music</a></li>
<li <?php $currPg='blog'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Blog</a></li>
<li <?php $currPg='artsandmusic'; echo $currPg==$_GET['p'] ? ' id="current"':''; ?> ><a href="?p=<?php echo $currPg; ?>">Arts & Music</a></li></ul>
</div>

<h4>Contact</h4>


  <form id="form2" method="post" class="contact_us" action="">
    <p><label>Name
    <input type="text" class="fields_contact_us" name="textfield" />
    </label>
    <label>E-mail
    <input type="text" class="fields_contact_us" name="textfield2" />
	</label>
	<label>
    Your message:
    <textarea name="textarea" cols="" rows=""></textarea>
	</label>
    <label>
    <input type="submit" class="submit_button_contact" name="Submit3" value="Submit" />
    </label></p>
  </form>

<h4>Suggested links </h4>



<a href="#">Lorem</a></div>
<div id="right">
<!-- %END HEADER% --><!-- %BEGIN CONTENT% -->
			<div align="center"><img src="images/demo_img.jpg" alt="Alt" height="200" /></div>
			<p>
			Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum sapien enim, cursus in, aliquam sit amet, convallis eget, metus. Duis dui mi, varius at, lacinia eget, ullamcorper et, tortor. Pellentesque ac pede. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean orci mi, varius eget, mollis vel, rhoncus a, leo. Ut eros enim, vehicula quis, gravida ac, sodales sit amet, orci. Nulla eleifend tristique erat. 
			</p>
			<div align="center">Ipsum Lorem Dolor</div><br />
              <br />

		      <!-- %END CONTENT% --><!-- %BEGIN FOOTER% -->  
</div>
<div id="footer" style="color:#999999">&copy; 2008 The Birth Experience | Christine Byrne, BSN, RN | <a href="http://www.csstemplateheaven.com">Related Websites </a> </div>
<!-- Based on a template from http://www.csstemplateheaven.com -->
</div>

<script type="text/javascript">
//<!--
	var theBrowser=navigator;
	if(theBrowser.appName=="Microsoft Internet Explorer" && (theBrowser.appVersion.substr(0,1)-0)<=4)
	{
		document.getElementById('left').style.marginLeft="22px";		
	}
//-->
</script>
</body>
</html>